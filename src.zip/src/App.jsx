import React from 'react'
import Navbar from './Components/Navbar/Navbar'
import Hero from './Components/Hero/Hero'
import About from './Components/About/About'
import Destination from './Components/Destination/Destination'
import Title from './Components/Title/Title'
import Destination2 from './Components/Destination/Destination2'
import Destination3 from './Components/Destination/Destination3'
import OurMember from './Components/OurMember/OurMember'
import Title2 from './Components/Title/Title2'


const App = () => {
  return (
    <div>
      <Navbar/>
      <Hero/>
      <div className="container">
        <About/>
        <Title/>
        <Destination/>
        <Destination2/>
        <Destination3/>
        <Title2/>
        <OurMember/>
      </div>
      </div>

  )
}

export default App
