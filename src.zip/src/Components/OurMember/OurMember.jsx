import React from 'react'
import './OurMember.css'
import member_1 from '../../assets/Member_1.png'
import member_2 from '../../assets/Member_2.png'
import member_3 from '../../assets/Member_3.png'
import member_4 from '../../assets/Member_4.png'

const OurMember = () => {
  return (
    <div className='members'>
      <div className="member">
        <img src={member_1} alt="" />
        </div>
     <div className='member'>
     <img src={member_2} alt="" />
     </div>
     <div className='member'>
     <img src={member_3} alt="" />
     </div>
     <div className='member'>
     <img src={member_4} alt="" />
     </div>
       
    </div>
  )
}

export default OurMember
