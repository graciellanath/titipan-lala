import React from 'react'
import './About.css'
import about_img from '../../assets/about.png'
import play_icon from '../../assets/play_icon.png'

const About = () => {
  return (
    <div className='about'>
      <div className='about-left'>
        <img src={about_img} alt="" className='about-img' />
        <img src={play_icon} alt="" className='play-icon'/>
      </div>
      <div className='about-right'>
      <h1>About Central Sulawesi</h1>
      <br/>
     <p>Central Sulawesi, nestled within the vibrant archipelago of Indonesia, is a captivating blend of natural wonders, rich cultural heritage, and warm hospitality. Picture lush rainforests teeming with exotic wildlife, including endemic species like the colorful anoa and the elusive babirusa, roaming freely in their pristine habitats. Here, towering mountains and cascading waterfalls beckon adventurous souls, offering thrilling hikes and breathtaking vistas.</p>
     <p> Delve into the heart of local communities, where ancient traditions and rituals are kept alive through vibrant festivals and intricate handicrafts, showcasing the region's diverse cultural tapestry. Along the tranquil shores, pristine beaches invite relaxation and exploration, while vibrant coral reefs beneath the azure waters promise unforgettable diving adventures. Central Sulawesi is not just a destination; it's an immersive journey into the soul of Indonesia, where every corner unveils a new story waiting to be discovered.</p>
      </div>
    </div>
  )
}

export default About
