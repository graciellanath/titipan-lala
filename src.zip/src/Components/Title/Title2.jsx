import React from 'react'
import './Title2.css'

const Title2 = () => {
  return (
    <div className='title'>
      <div className='title-text'>
        <h1>Our Member</h1>
      </div>
    </div>
  )
}

export default Title2
