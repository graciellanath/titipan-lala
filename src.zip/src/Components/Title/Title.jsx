import React from 'react'
import './Title.css'

const Title = () => {
  return (
    <div className='title'>
      <div className='title-text'>
        <h1>Destination</h1>
      </div>
    </div>
  )
}

export default Title
