import React from 'react';
import './Destination.css'; 
import pantai from '../../assets/pantai.png'
import danau from '../../assets/danau.png'
import banggai from '../../assets/banggai.png'

const DestinationCards = () => {
  return (
    <><div className="destination-container">
          {/* Card 1 */}
          <div className="destination-card">
              <img src={banggai} alt="Destination 1" className="destination-image" />
              <div className="destination-info">
                  <h2>Lake Paisu Pok Luk Panenteng</h2>
                  <p>Sparkling amidst the Banggai Islands of Central Sulawesi, it offers a captivating natural charm with calm waters and enticing mysteries</p>

              </div>
          </div>

          {/* Card 2 */}
          <div className="destination-card">
              <img src={pantai} alt="Destination 2" className="destination-image" />
              <div className="destination-info">
                  <h2>Tanjung Karang Beach</h2>
                  <p>A tropical paradise in Central Sulawesi that offers pristine white sands, crystal blue sea waters, and stunning natural landscapes</p>
              </div>
          </div>

          {/* Card 3 */}
          <div className="destination-card">
              <img src={danau} alt="Destination 3" className="destination-image" />
              <div className="destination-info">
                  <h2>Lake Poso</h2>
                  <p>A blue gem in the heart of Central Sulawesi, captivating with its enchanting natural beauty and profound cultural richness</p>

              </div>
          </div>
      </div>
      
      <br/></>
  );
}

export default DestinationCards;
