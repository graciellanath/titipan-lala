import React from 'react'
import './Hero.css'
import right_arrow from '../../assets/right_arrow.png'
import backgroundH from "../../assets/hero.gif"
  

const Hero = () => {
  return (
    <div className='hero'>
      <div className='hero-text'>
        <h1>Unveiling Central Sulawesi</h1>
        <p>Your Gateway To Central Sulawesi</p>
        <button className='btn'>Start Your Journey <img src={right_arrow} alt="" /></button>
      </div>
    </div>
  )
}

export default Hero
